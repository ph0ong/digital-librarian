# Digital Library System

## Overview

This is a full-stack digital library application built with React, Express, and PostgreSQL. The system provides a comprehensive platform for managing digital books, allowing users to browse, search, download, and review books. It features a modern web interface with Vietnamese language support and includes administrative functionality for content management.

## System Architecture

The application follows a modern full-stack architecture with clear separation between frontend and backend components:

- **Frontend**: React-based SPA with TypeScript, built using Vite
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth integration with session management
- **UI Framework**: shadcn/ui components with Tailwind CSS
- **File Upload**: Multer for PDF file handling
- **Deployment**: Configured for Replit's autoscale environment

## Key Components

### Frontend Architecture
- **React Router**: Using Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom theming support (light/dark mode)
- **Form Management**: React Hook Form with Zod validation
- **Type Safety**: Full TypeScript implementation with shared types

### Backend Architecture
- **API Layer**: RESTful Express.js server with TypeScript
- **Database Layer**: Drizzle ORM with PostgreSQL
- **Authentication**: Replit Auth with OpenID Connect
- **Session Management**: PostgreSQL-backed session storage
- **File Storage**: Local file system with multer for PDF uploads
- **Middleware**: Custom logging, error handling, and authentication middleware

### Database Schema
The database includes the following main entities:
- **Users**: Authentication and profile information
- **Books**: Core book metadata (title, author, description, etc.)
- **Categories**: Book categorization system
- **Reviews**: User reviews and ratings
- **Bookmarks**: User's saved books
- **Downloads**: Download tracking
- **Sessions**: Authentication session storage

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit Auth, sessions stored in PostgreSQL
2. **Book Discovery**: Users browse/search books with filtering and pagination
3. **Book Management**: Admins can upload PDFs and manage book metadata
4. **User Interactions**: Users can bookmark, review, and download books
5. **Content Delivery**: PDF files served directly from the server's file system

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection pooling
- **drizzle-orm**: Type-safe database ORM
- **passport**: Authentication middleware
- **multer**: File upload handling
- **react-hook-form**: Form management
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight routing
- **recharts**: Data visualization for admin dashboard

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library
- **class-variance-authority**: Component variant management

## Deployment Strategy

The application is configured for deployment on Replit's platform:

- **Development**: Uses Vite dev server with Express backend
- **Production**: Builds static assets and runs Express server
- **Database**: PostgreSQL module configured via Replit
- **File Storage**: Local uploads directory (not suitable for distributed deployment)
- **Environment**: Uses Replit-specific environment variables and authentication

### Build Process
1. Frontend assets built with Vite to `dist/public`
2. Backend compiled with esbuild to `dist/index.js`
3. Server serves both static files and API routes
4. Database migrations managed via Drizzle Kit

### Key Configuration Files
- **vite.config.ts**: Frontend build configuration
- **drizzle.config.ts**: Database schema and migration settings
- **.replit**: Replit-specific deployment configuration
- **package.json**: Scripts for development, build, and production

## Changelog

Changelog:
- June 21, 2025: Initial setup with complete digital library system
- June 21, 2025: Created deployment package (digital-library-complete.tar.gz) containing full source code

## User Preferences

Preferred communication style: Simple, everyday language.