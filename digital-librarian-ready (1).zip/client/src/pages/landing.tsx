import { Link } from "wouter";
import { BookOpen, Search, Star, Download, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-slate-900 dark:to-slate-800">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="text-center">
          <div className="flex justify-center mb-8">
            <div className="bg-primary p-4 rounded-2xl">
              <BookOpen className="h-16 w-16 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white sm:text-5xl md:text-6xl">
            Thư Viện Số
          </h1>
          <p className="mt-3 text-xl text-gray-600 dark:text-gray-300 sm:mt-5 sm:text-2xl">
            Digital Library
          </p>
          <p className="mt-5 max-w-md mx-auto text-base text-gray-500 dark:text-gray-400 sm:text-lg md:mt-8 md:text-xl md:max-w-3xl">
            Nền tảng thư viện số hàng đầu Việt Nam, cung cấp hàng ngàn tài liệu chất lượng cao 
            cho học tập và nghiên cứu. Khám phá kho tri thức phong phú với giao diện hiện đại.
          </p>
          
          <div className="mt-8 flex justify-center">
            <Button asChild size="lg" className="px-8 py-3 text-lg">
              <a href="/api/login">
                Bắt đầu ngay
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
            Tính năng nổi bật
          </h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
            Trải nghiệm đọc sách số hoàn toàn mới với những tính năng tiện ích
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto bg-blue-100 dark:bg-blue-900 p-3 rounded-full w-fit">
                <Search className="h-8 w-8 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle>Tìm kiếm thông minh</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300">
                Tìm kiếm nhanh chóng với bộ lọc nâng cao theo tác giả, thể loại, đánh giá
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto bg-green-100 dark:bg-green-900 p-3 rounded-full w-fit">
                <Download className="h-8 w-8 text-green-600 dark:text-green-400" />
              </div>
              <CardTitle>Tải xuống dễ dàng</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300">
                Tải xuống PDF chất lượng cao, đọc offline mọi lúc mọi nơi
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto bg-amber-100 dark:bg-amber-900 p-3 rounded-full w-fit">
                <Star className="h-8 w-8 text-amber-600 dark:text-amber-400" />
              </div>
              <CardTitle>Đánh giá và nhận xét</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300">
                Hệ thống đánh giá 5 sao và bình luận từ cộng đồng độc giả
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto bg-purple-100 dark:bg-purple-900 p-3 rounded-full w-fit">
                <BookOpen className="h-8 w-8 text-purple-600 dark:text-purple-400" />
              </div>
              <CardTitle>Kho sách phong phú</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300">
                Hàng ngàn đầu sách từ nhiều lĩnh vực: công nghệ, khoa học, văn học
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-primary/5 dark:bg-primary/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
              Sẵn sàng khám phá thế giới tri thức?
            </h2>
            <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
              Tham gia cộng đồng hàng ngàn độc giả đang sử dụng Thư Viện Số
            </p>
            <div className="mt-8">
              <Button asChild size="lg" className="px-8 py-3 text-lg">
                <a href="/api/login">
                  Đăng nhập ngay
                  <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white dark:bg-slate-800 border-t border-gray-200 dark:border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-primary p-2 rounded-lg">
                  <BookOpen className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Thư Viện Số</h3>
                  <p className="text-sm text-muted-foreground">Digital Library</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                Nền tảng thư viện số hàng đầu Việt Nam, cung cấp hàng ngàn tài liệu chất lượng cao 
                cho học tập và nghiên cứu.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Liên kết</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><Link href="/about">Giới thiệu</Link></li>
                <li><Link href="/terms">Điều khoản</Link></li>
                <li><Link href="/privacy">Chính sách</Link></li>
                <li><Link href="/contact">Liên hệ</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Hỗ trợ</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><Link href="/help">Trung tâm trợ giúp</Link></li>
                <li><Link href="/guide">Hướng dẫn</Link></li>
                <li><Link href="/faq">FAQ</Link></li>
                <li><Link href="/report">Báo lỗi</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 Thư Viện Số. Tất cả quyền được bảo lưu.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
