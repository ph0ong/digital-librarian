import { useState } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, Download, Eye, Bookmark, Star, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Header } from "@/components/header";
import { Navigation } from "@/components/navigation";
import type { BookWithDetails, ReviewWithUser } from "@shared/schema";

const reviewSchema = z.object({
  rating: z.number().min(1).max(5),
  comment: z.string().optional(),
});

export default function BookDetail() {
  const params = useParams();
  const bookId = parseInt(params.id as string);
  const [selectedRating, setSelectedRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, isAuthenticated } = useAuth();

  const { data: book, isLoading } = useQuery<BookWithDetails>({
    queryKey: [`/api/books/${bookId}`],
    enabled: !!bookId,
  });

  const { data: reviews = [] } = useQuery<ReviewWithUser[]>({
    queryKey: [`/api/books/${bookId}/reviews`],
    enabled: !!bookId,
  });

  const form = useForm<z.infer<typeof reviewSchema>>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      rating: 0,
      comment: "",
    },
  });

  const downloadMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/books/${bookId}/download`);
      if (!response.ok) {
        throw new Error(`Download failed: ${response.statusText}`);
      }
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = book?.fileName || `${book?.title}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast({
        title: "Tải xuống thành công",
        description: `Đã tải xuống "${book?.title}"`,
      });
    },
    onError: (error) => {
      toast({
        title: "Lỗi tải xuống",
        description: error.message || "Không thể tải xuống sách",
        variant: "destructive",
      });
    },
  });

  const bookmarkMutation = useMutation({
    mutationFn: async () => {
      if (book?.isBookmarked) {
        await apiRequest("DELETE", `/api/books/${bookId}/bookmark`);
      } else {
        await apiRequest("POST", `/api/books/${bookId}/bookmark`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/books/${bookId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
      toast({
        title: book?.isBookmarked ? "Đã bỏ yêu thích" : "Đã thêm vào yêu thích",
        description: `"${book?.title}" ${book?.isBookmarked ? "đã được bỏ khỏi" : "đã được thêm vào"} danh sách yêu thích`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Lỗi",
        description: error.message || "Không thể thực hiện thao tác",
        variant: "destructive",
      });
    },
  });

  const reviewMutation = useMutation({
    mutationFn: async (data: z.infer<typeof reviewSchema>) => {
      await apiRequest("POST", `/api/books/${bookId}/reviews`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/books/${bookId}/reviews`] });
      queryClient.invalidateQueries({ queryKey: [`/api/books/${bookId}`] });
      form.reset();
      setSelectedRating(0);
      toast({
        title: "Thành công",
        description: "Đánh giá của bạn đã được gửi",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Lỗi",
        description: error.message || "Không thể gửi đánh giá",
        variant: "destructive",
      });
    },
  });

  const onSubmitReview = (data: z.infer<typeof reviewSchema>) => {
    if (selectedRating === 0) {
      toast({
        title: "Lỗi",
        description: "Vui lòng chọn số sao đánh giá",
        variant: "destructive",
      });
      return;
    }
    reviewMutation.mutate({ ...data, rating: selectedRating });
  };

  const renderStars = (rating: number, interactive = false, size = "h-5 w-5") => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`${size} cursor-pointer transition-colors ${
          i < (interactive ? (hoverRating || selectedRating) : Math.floor(rating))
            ? "fill-amber-400 text-amber-400"
            : "text-gray-300"
        }`}
        onClick={interactive ? () => setSelectedRating(i + 1) : undefined}
        onMouseEnter={interactive ? () => setHoverRating(i + 1) : undefined}
        onMouseLeave={interactive ? () => setHoverRating(0) : undefined}
      />
    ));
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("vi-VN", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="h-96 bg-muted rounded"></div>
              <div className="md:col-span-2 space-y-4">
                <div className="h-8 bg-muted rounded w-3/4"></div>
                <div className="h-6 bg-muted rounded w-1/2"></div>
                <div className="h-24 bg-muted rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-muted-foreground">Không tìm thấy sách</h1>
            <Button asChild className="mt-4">
              <a href="/">Quay về trang chủ</a>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <Button variant="ghost" asChild className="mb-6">
          <a href="/">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Quay lại
          </a>
        </Button>

        {/* Book Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="md:col-span-1">
            {/* Book Cover Placeholder */}
            <div className="w-full aspect-[3/4] bg-gradient-to-br from-blue-100 to-blue-200 dark:from-blue-900 dark:to-blue-800 rounded-xl shadow-lg flex items-center justify-center">
              <div className="text-center p-8">
                <div className="text-4xl font-bold text-blue-600 dark:text-blue-300 mb-4">
                  {book.title.slice(0, 2).toUpperCase()}
                </div>
                <div className="text-sm text-blue-500 dark:text-blue-400 line-clamp-3">
                  {book.title}
                </div>
              </div>
            </div>
          </div>

          <div className="md:col-span-2">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold mb-2">{book.title}</h1>
                <p className="text-xl text-muted-foreground">{book.author}</p>
              </div>
              <div className="flex space-x-2">
                <Badge variant={book.isFree ? "secondary" : "default"}>
                  {book.isFree ? "Miễn phí" : "Premium"}
                </Badge>
                {book.category && (
                  <Badge variant="outline">{book.category.name}</Badge>
                )}
              </div>
            </div>

            <div className="flex items-center space-x-4 mb-6">
              <div className="flex items-center">
                {renderStars(book.averageRating || 0)}
                <span className="ml-2 text-lg font-medium">
                  {book.averageRating?.toFixed(1) || "0.0"}
                </span>
                <span className="text-muted-foreground ml-1">
                  ({book.totalRatings || 0} đánh giá)
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-primary">
                    {book.downloadCount || 0}
                  </div>
                  <div className="text-sm text-muted-foreground">Lượt tải</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-primary">
                    {book.pageCount || "N/A"}
                  </div>
                  <div className="text-sm text-muted-foreground">Trang</div>
                </CardContent>
              </Card>
            </div>

            {book.description && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Mô tả</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {book.description}
                </p>
              </div>
            )}

            <div className="flex space-x-4">
              <Button
                onClick={() => downloadMutation.mutate()}
                disabled={downloadMutation.isPending}
                className="flex-1"
              >
                <Download className="h-4 w-4 mr-2" />
                {downloadMutation.isPending ? "Đang tải..." : "Tải xuống PDF"}
              </Button>
              <Button variant="outline" disabled>
                <Eye className="h-4 w-4 mr-2" />
                Xem trước
              </Button>
              {isAuthenticated && (
                <Button
                  variant="outline"
                  onClick={() => bookmarkMutation.mutate()}
                  disabled={bookmarkMutation.isPending}
                >
                  <Bookmark
                    className={`h-4 w-4 mr-2 ${
                      book.isBookmarked ? "fill-current" : ""
                    }`}
                  />
                  {book.isBookmarked ? "Đã lưu" : "Lưu"}
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <Card>
          <CardHeader>
            <CardTitle>Đánh giá và nhận xét</CardTitle>
          </CardHeader>
          <CardContent>
            {/* Review Form */}
            {isAuthenticated && (
              <Card className="mb-6">
                <CardContent className="p-6">
                  <h4 className="font-medium mb-4">Viết đánh giá</h4>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmitReview)} className="space-y-4">
                      <div>
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="text-sm text-muted-foreground">Đánh giá:</span>
                          <div className="flex">
                            {renderStars(selectedRating, true)}
                          </div>
                        </div>
                      </div>

                      <FormField
                        control={form.control}
                        name="comment"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Textarea
                                placeholder="Nhận xét của bạn về cuốn sách..."
                                className="resize-none"
                                rows={3}
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button type="submit" disabled={reviewMutation.isPending}>
                        <Send className="h-4 w-4 mr-2" />
                        {reviewMutation.isPending ? "Đang gửi..." : "Gửi đánh giá"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            )}

            {/* Reviews List */}
            <div className="space-y-6">
              {reviews.length > 0 ? (
                reviews.map((review) => (
                  <div key={review.id}>
                    <div className="flex items-start space-x-4">
                      <Avatar>
                        <AvatarImage src={review.user.profileImageUrl || ""} />
                        <AvatarFallback>
                          {review.user.firstName?.[0] || review.user.email?.[0] || "U"}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">
                            {review.user.firstName || review.user.email}
                          </h4>
                          <span className="text-sm text-muted-foreground">
                            {review.createdAt && formatDate(review.createdAt.toString())}
                          </span>
                        </div>
                        <div className="flex items-center mb-2">
                          {renderStars(review.rating, false, "h-4 w-4")}
                        </div>
                        {review.comment && (
                          <p className="text-muted-foreground">{review.comment}</p>
                        )}
                      </div>
                    </div>
                    <Separator className="mt-6" />
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  Chưa có đánh giá nào cho cuốn sách này
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
