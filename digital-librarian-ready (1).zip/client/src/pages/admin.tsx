import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Users, BookOpen, Download, Star, TrendingUp, Calendar, FileText, Shield } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { Header } from "@/components/header";
import { Navigation } from "@/components/navigation";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Book, User } from "@shared/schema";

interface AdminStats {
  totalBooks: number;
  totalUsers: number;
  totalDownloads: number;
  totalReviews: number;
}

export default function Admin() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();

  // Redirect to home if not authenticated or not admin
  useEffect(() => {
    if (!authLoading && (!isAuthenticated || !user?.isAdmin)) {
      toast({
        title: "Unauthorized",
        description: "You need admin access to view this page",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 500);
      return;
    }
  }, [isAuthenticated, user, authLoading, toast]);

  const { data: stats } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
    retry: false,
    enabled: isAuthenticated && user?.isAdmin,
  });

  const { data: recentBooks = [] } = useQuery<Book[]>({
    queryKey: ["/api/admin/recent-books", { limit: 10 }],
    retry: false,
    enabled: isAuthenticated && user?.isAdmin,
  });

  const { data: popularBooks = [] } = useQuery<Book[]>({
    queryKey: ["/api/books/popular", { limit: 10 }],
    retry: false,
    enabled: isAuthenticated && user?.isAdmin,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-32 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user?.isAdmin) {
    return null; // Will redirect via useEffect
  }

  const statsCards = [
    {
      title: "Tổng sách",
      value: stats?.totalBooks || 0,
      icon: BookOpen,
      gradient: "from-blue-500 to-blue-600",
      iconColor: "text-blue-200",
    },
    {
      title: "Người dùng",
      value: stats?.totalUsers || 0,
      icon: Users,
      gradient: "from-green-500 to-green-600",
      iconColor: "text-green-200",
    },
    {
      title: "Lượt tải",
      value: stats?.totalDownloads || 0,
      icon: Download,
      gradient: "from-purple-500 to-purple-600",
      iconColor: "text-purple-200",
    },
    {
      title: "Đánh giá",
      value: stats?.totalReviews || 0,
      icon: Star,
      gradient: "from-amber-500 to-amber-600",
      iconColor: "text-amber-200",
    },
  ];

  // Sample data for charts (in a real app, this would come from API)
  const monthlyDownloads = [
    { name: "Jan", downloads: 1200 },
    { name: "Feb", downloads: 1900 },
    { name: "Mar", downloads: 3000 },
    { name: "Apr", downloads: 2800 },
    { name: "May", downloads: 3900 },
    { name: "Jun", downloads: 4300 },
  ];

  const categoryData = [
    { name: "Công nghệ", value: 45, color: "#3B82F6" },
    { name: "Khoa học", value: 30, color: "#10B981" },
    { name: "Văn học", value: 15, color: "#F59E0B" },
    { name: "Khác", value: 10, color: "#8B5CF6" },
  ];

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + "M";
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + "K";
    }
    return num.toString();
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center">
              <Shield className="h-8 w-8 mr-3 text-primary" />
              Admin Dashboard
            </h1>
            <p className="text-muted-foreground mt-2">
              Quản lý và theo dõi hoạt động của thư viện số
            </p>
          </div>
          <Badge variant="secondary" className="px-3 py-1">
            <Shield className="h-4 w-4 mr-1" />
            Admin Access
          </Badge>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statsCards.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.title} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className={`bg-gradient-to-r ${stat.gradient} p-6 text-white`}>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white/80 text-sm font-medium">{stat.title}</p>
                        <p className="text-3xl font-bold">{formatNumber(stat.value)}</p>
                      </div>
                      <Icon className={`h-8 w-8 ${stat.iconColor}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full lg:w-[400px] grid-cols-3">
            <TabsTrigger value="overview">Tổng quan</TabsTrigger>
            <TabsTrigger value="books">Quản lý sách</TabsTrigger>
            <TabsTrigger value="analytics">Phân tích</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Monthly Downloads Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2" />
                    Lượt tải theo tháng
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={monthlyDownloads}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="downloads" fill="hsl(var(--primary))" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Category Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle>Phân bố theo danh mục</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Popular Books */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="h-5 w-5 mr-2" />
                  Sách phổ biến nhất
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {popularBooks.slice(0, 5).map((book, index) => (
                    <div key={book.id} className="flex items-center space-x-4 p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center justify-center w-8 h-8 bg-primary text-primary-foreground rounded-full text-sm font-bold">
                        {index + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium truncate">{book.title}</h4>
                        <p className="text-sm text-muted-foreground">{book.author}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">{book.downloadCount || 0} lượt tải</div>
                        <div className="text-xs text-muted-foreground">
                          {book.averageRating?.toFixed(1) || "0.0"} ⭐
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="books" className="space-y-6">
            {/* Recent Books */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Sách mới nhất
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentBooks.map((book) => (
                    <div key={book.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                      <div className="w-16 h-20 bg-gradient-to-br from-blue-100 to-blue-200 dark:from-blue-900 dark:to-blue-800 rounded flex items-center justify-center">
                        <FileText className="h-6 w-6 text-blue-600 dark:text-blue-300" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{book.title}</h4>
                        <p className="text-sm text-muted-foreground">{book.author}</p>
                        <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                          <span>{book.downloadCount || 0} lượt tải</span>
                          <span>{book.totalRatings || 0} đánh giá</span>
                          <Badge variant={book.isFree ? "secondary" : "default"} className="text-xs">
                            {book.isFree ? "Miễn phí" : "Premium"}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          Chỉnh sửa
                        </Button>
                        <Button variant="outline" size="sm" className="text-destructive">
                          Xóa
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Downloads Over Time */}
              <Card>
                <CardHeader>
                  <CardTitle>Xu hướng tải xuống</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={monthlyDownloads}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="downloads" fill="hsl(var(--primary))" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Usage Statistics */}
              <Card>
                <CardHeader>
                  <CardTitle>Thống kê sử dụng</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-muted/50 rounded">
                    <span className="text-sm font-medium">Sách được tải nhiều nhất</span>
                    <span className="text-2xl font-bold text-primary">
                      {Math.max(...popularBooks.map(b => b.downloadCount || 0))}
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-muted/50 rounded">
                    <span className="text-sm font-medium">Đánh giá trung bình</span>
                    <span className="text-2xl font-bold text-primary">
                      {popularBooks.length > 0 
                        ? (popularBooks.reduce((acc, book) => acc + (book.averageRating || 0), 0) / popularBooks.length).toFixed(1)
                        : "0.0"
                      }
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-muted/50 rounded">
                    <span className="text-sm font-medium">Sách miễn phí</span>
                    <span className="text-2xl font-bold text-primary">
                      {recentBooks.filter(book => book.isFree).length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-muted/50 rounded">
                    <span className="text-sm font-medium">Tổng số trang</span>
                    <span className="text-2xl font-bold text-primary">
                      {formatNumber(recentBooks.reduce((acc, book) => acc + (book.pageCount || 0), 0))}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
