import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Filter, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import type { Category } from "@shared/schema";

interface SearchFiltersProps {
  onFiltersChange: (filters: {
    categoryId?: number;
    sortBy?: string;
    minRating?: number;
    language?: string;
    year?: number;
  }) => void;
  initialFilters?: any;
}

export function SearchFilters({ onFiltersChange, initialFilters = {} }: SearchFiltersProps) {
  const [filters, setFilters] = useState(initialFilters);
  const [isOpen, setIsOpen] = useState(false);

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  useEffect(() => {
    onFiltersChange(filters);
  }, [filters, onFiltersChange]);

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value === "" ? undefined : value,
    }));
  };

  const clearFilters = () => {
    setFilters({});
  };

  const activeFiltersCount = Object.values(filters).filter(Boolean).length;

  const renderStars = (count: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <span key={i} className={i < count ? "text-amber-400" : "text-gray-300"}>
        ★
      </span>
    ));
  };

  return (
    <div className="space-y-6">
      {/* Mobile Filter Toggle */}
      <div className="lg:hidden">
        <Button
          variant="outline"
          onClick={() => setIsOpen(!isOpen)}
          className="w-full flex items-center justify-between"
        >
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4" />
            <span>Bộ lọc</span>
            {activeFiltersCount > 0 && (
              <Badge variant="secondary" className="ml-2">
                {activeFiltersCount}
              </Badge>
            )}
          </div>
        </Button>
      </div>

      <Collapsible open={isOpen} onOpenChange={setIsOpen} className="lg:block">
        <CollapsibleContent className="space-y-6">
          {/* Active Filters */}
          {activeFiltersCount > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm">Bộ lọc đang áp dụng</CardTitle>
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex flex-wrap gap-2">
                  {filters.categoryId && (
                    <Badge variant="secondary" className="flex items-center gap-1">
                      Danh mục: {categories.find(c => c.id === filters.categoryId)?.name}
                      <X 
                        className="h-3 w-3 cursor-pointer" 
                        onClick={() => handleFilterChange("categoryId", undefined)}
                      />
                    </Badge>
                  )}
                  {filters.minRating && (
                    <Badge variant="secondary" className="flex items-center gap-1">
                      {filters.minRating}+ sao
                      <X 
                        className="h-3 w-3 cursor-pointer" 
                        onClick={() => handleFilterChange("minRating", undefined)}
                      />
                    </Badge>
                  )}
                  {filters.language && (
                    <Badge variant="secondary" className="flex items-center gap-1">
                      {filters.language === "vi" ? "Tiếng Việt" : "English"}
                      <X 
                        className="h-3 w-3 cursor-pointer" 
                        onClick={() => handleFilterChange("language", undefined)}
                      />
                    </Badge>
                  )}
                  {filters.year && (
                    <Badge variant="secondary" className="flex items-center gap-1">
                      Năm {filters.year}
                      <X 
                        className="h-3 w-3 cursor-pointer" 
                        onClick={() => handleFilterChange("year", undefined)}
                      />
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Categories */}
          <Card>
            <CardHeader>
              <CardTitle>Danh mục</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {categories.map((category) => (
                <div key={category.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={`category-${category.id}`}
                    checked={filters.categoryId === category.id}
                    onCheckedChange={(checked) =>
                      handleFilterChange("categoryId", checked ? category.id : undefined)
                    }
                  />
                  <Label
                    htmlFor={`category-${category.id}`}
                    className="text-sm font-normal cursor-pointer flex-1"
                  >
                    {category.name}
                  </Label>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Rating Filter */}
          <Card>
            <CardHeader>
              <CardTitle>Đánh giá</CardTitle>
            </CardHeader>
            <CardContent>
              <RadioGroup
                value={filters.minRating?.toString() || ""}
                onValueChange={(value) => handleFilterChange("minRating", value ? parseInt(value) : undefined)}
              >
                {[5, 4, 3, 2, 1].map((rating) => (
                  <div key={rating} className="flex items-center space-x-2">
                    <RadioGroupItem value={rating.toString()} id={`rating-${rating}`} />
                    <Label htmlFor={`rating-${rating}`} className="flex items-center space-x-2 cursor-pointer">
                      <div className="flex">{renderStars(rating)}</div>
                      <span className="text-sm">{rating}+ sao</span>
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Advanced Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Bộ lọc nâng cao</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium mb-2 block">Năm xuất bản</Label>
                <Select 
                  value={filters.year?.toString() || ""} 
                  onValueChange={(value) => handleFilterChange("year", value ? parseInt(value) : undefined)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Tất cả" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Tất cả</SelectItem>
                    <SelectItem value="2024">2024</SelectItem>
                    <SelectItem value="2023">2023</SelectItem>
                    <SelectItem value="2022">2022</SelectItem>
                    <SelectItem value="2021">2021</SelectItem>
                    <SelectItem value="2020">2020</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="text-sm font-medium mb-2 block">Ngôn ngữ</Label>
                <Select 
                  value={filters.language || ""} 
                  onValueChange={(value) => handleFilterChange("language", value || undefined)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Tất cả" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Tất cả</SelectItem>
                    <SelectItem value="vi">Tiếng Việt</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}
