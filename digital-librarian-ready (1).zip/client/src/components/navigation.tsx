import { Link, useLocation } from "wouter";
import { Home, Layers, Star, Download, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { useAuth } from "@/hooks/useAuth";

interface NavigationProps {
  onAddBook?: () => void;
}

export function Navigation({ onAddBook }: NavigationProps) {
  const [location] = useLocation();
  const { isAuthenticated } = useAuth();

  const navItems = [
    { href: "/", label: "Trang chủ", icon: Home },
    { href: "/categories", label: "Danh mục", icon: Layers },
    { href: "/bookmarks", label: "Yêu thích", icon: Star },
    { href: "/downloads", label: "Đã tải", icon: Download },
  ];

  const getBreadcrumbs = () => {
    const paths = location.split("/").filter(Boolean);
    const breadcrumbs = [{ href: "/", label: "Trang chủ" }];

    if (paths.length > 0) {
      if (paths[0] === "categories") {
        breadcrumbs.push({ href: "/categories", label: "Danh mục" });
        if (paths[1]) {
          breadcrumbs.push({ href: `/${paths.join("/")}`, label: "Lập trình" });
        }
      } else if (paths[0] === "bookmarks") {
        breadcrumbs.push({ href: "/bookmarks", label: "Yêu thích" });
      } else if (paths[0] === "admin") {
        breadcrumbs.push({ href: "/admin", label: "Quản trị" });
      }
    }

    return breadcrumbs;
  };

  const breadcrumbs = getBreadcrumbs();

  return (
    <>
      {/* Main Navigation */}
      <nav className="bg-background border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-12">
            <div className="flex items-center space-x-8">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href;
                
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center space-x-2 text-sm font-medium pb-3 border-b-2 transition-colors ${
                      isActive
                        ? "text-primary border-primary"
                        : "text-muted-foreground border-transparent hover:text-primary"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </div>
            
            {isAuthenticated && (
              <Button onClick={onAddBook} className="flex items-center space-x-2">
                <Plus className="h-4 w-4" />
                <span>Thêm sách</span>
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Breadcrumbs */}
      {breadcrumbs.length > 1 && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Breadcrumb>
            <BreadcrumbList>
              {breadcrumbs.map((crumb, index) => (
                <BreadcrumbItem key={crumb.href}>
                  {index === breadcrumbs.length - 1 ? (
                    <BreadcrumbPage>{crumb.label}</BreadcrumbPage>
                  ) : (
                    <>
                      <BreadcrumbLink asChild>
                        <Link href={crumb.href}>{crumb.label}</Link>
                      </BreadcrumbLink>
                      <BreadcrumbSeparator />
                    </>
                  )}
                </BreadcrumbItem>
              ))}
            </BreadcrumbList>
          </Breadcrumb>
        </div>
      )}
    </>
  );
}
