import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Download, Eye, Bookmark, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useAuth } from "@/hooks/useAuth";
import type { BookWithDetails } from "@shared/schema";

interface BookCardProps {
  book: BookWithDetails;
  onView?: (book: BookWithDetails) => void;
}

export function BookCard({ book, onView }: BookCardProps) {
  const [isBookmarked, setIsBookmarked] = useState(book.isBookmarked || false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isAuthenticated } = useAuth();

  const downloadMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/books/${book.id}/download`);
      if (!response.ok) {
        throw new Error(`Download failed: ${response.statusText}`);
      }
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = book.fileName || `${book.title}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast({
        title: "Tải xuống thành công",
        description: `Đã tải xuống "${book.title}"`,
      });
    },
    onError: (error) => {
      toast({
        title: "Lỗi tải xuống",
        description: error.message || "Không thể tải xuống sách",
        variant: "destructive",
      });
    },
  });

  const bookmarkMutation = useMutation({
    mutationFn: async () => {
      if (isBookmarked) {
        await apiRequest("DELETE", `/api/books/${book.id}/bookmark`);
      } else {
        await apiRequest("POST", `/api/books/${book.id}/bookmark`);
      }
    },
    onSuccess: () => {
      setIsBookmarked(!isBookmarked);
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
      toast({
        title: isBookmarked ? "Đã bỏ yêu thích" : "Đã thêm vào yêu thích",
        description: `"${book.title}" ${isBookmarked ? "đã được bỏ khỏi" : "đã được thêm vào"} danh sách yêu thích`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Lỗi",
        description: error.message || "Không thể thực hiện thao tác",
        variant: "destructive",
      });
    },
  });

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < Math.floor(rating) ? "fill-amber-400 text-amber-400" : "text-gray-300"
        }`}
      />
    ));
  };

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAuthenticated) {
      toast({
        title: "Cần đăng nhập",
        description: "Bạn cần đăng nhập để sử dụng tính năng này",
        variant: "destructive",
      });
      return;
    }
    bookmarkMutation.mutate();
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    downloadMutation.mutate();
  };

  const handleView = () => {
    if (onView) {
      onView(book);
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 group cursor-pointer">
      <div className="relative" onClick={handleView}>
        {/* Placeholder for book cover */}
        <div className="w-full h-48 bg-gradient-to-br from-blue-100 to-blue-200 dark:from-blue-900 dark:to-blue-800 flex items-center justify-center">
          <div className="text-center p-4">
            <div className="text-2xl font-bold text-blue-600 dark:text-blue-300 mb-2">
              {book.title.slice(0, 2).toUpperCase()}
            </div>
            <div className="text-xs text-blue-500 dark:text-blue-400 line-clamp-2">
              {book.title}
            </div>
          </div>
        </div>
        
        <div className="absolute top-3 right-3">
          <Button
            variant="secondary"
            size="icon"
            className="rounded-full shadow-lg hover:bg-red-50 dark:hover:bg-red-900/20"
            onClick={handleBookmark}
            disabled={bookmarkMutation.isPending}
          >
            <Bookmark 
              className={`h-4 w-4 ${isBookmarked ? "fill-red-500 text-red-500" : "text-muted-foreground"}`} 
            />
          </Button>
        </div>
        
        <div className="absolute top-3 left-3">
          <Badge variant={book.isFree ? "secondary" : "default"}>
            {book.isFree ? "Miễn phí" : "Premium"}
          </Badge>
        </div>
      </div>
      
      <CardContent className="p-6">
        <div className="mb-2">
          <h3 className="font-semibold text-lg text-foreground group-hover:text-primary transition-colors line-clamp-2">
            {book.title}
          </h3>
        </div>
        
        <p className="text-sm text-muted-foreground mb-3">{book.author}</p>
        
        <div className="flex items-center mb-3">
          <div className="flex">
            {renderStars(book.averageRating || 0)}
          </div>
          <span className="text-sm text-muted-foreground ml-2">
            {book.averageRating?.toFixed(1) || "0.0"} ({book.totalRatings || 0} đánh giá)
          </span>
        </div>
        
        <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
          <span>
            <Download className="h-4 w-4 inline mr-1" />
            {book.downloadCount || 0} lượt tải
          </span>
          <span>
            <Eye className="h-4 w-4 inline mr-1" />
            PDF
          </span>
        </div>
        
        <div className="flex space-x-2">
          <Button 
            className="flex-1" 
            onClick={handleDownload}
            disabled={downloadMutation.isPending}
          >
            <Download className="h-4 w-4 mr-2" />
            {downloadMutation.isPending ? "Đang tải..." : "Tải xuống"}
          </Button>
          <Button variant="outline" size="icon" onClick={handleView}>
            <Eye className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
