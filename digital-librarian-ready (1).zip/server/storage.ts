import {
  users,
  books,
  categories,
  reviews,
  bookmarks,
  downloads,
  type User,
  type UpsertUser,
  type Book,
  type InsertBook,
  type Category,
  type InsertCategory,
  type Review,
  type InsertReview,
  type Bookmark,
  type InsertBookmark,
  type Download,
  type BookWithDetails,
  type ReviewWithUser,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, or, like, ilike, sql, count } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Category operations
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Book operations
  getBooks(params: {
    page?: number;
    limit?: number;
    search?: string;
    categoryId?: number;
    sortBy?: "newest" | "rating" | "downloads" | "title";
    minRating?: number;
    language?: string;
    year?: number;
  }): Promise<{ books: BookWithDetails[]; total: number }>;
  getBookById(id: number, userId?: string): Promise<BookWithDetails | undefined>;
  createBook(book: InsertBook): Promise<Book>;
  updateBook(id: number, book: Partial<InsertBook>): Promise<Book | undefined>;
  deleteBook(id: number): Promise<boolean>;
  incrementDownloadCount(bookId: number): Promise<void>;

  // Review operations
  getBookReviews(bookId: number): Promise<ReviewWithUser[]>;
  createReview(review: InsertReview): Promise<Review>;
  updateBookRating(bookId: number): Promise<void>;

  // Bookmark operations
  getBookmarks(userId: string): Promise<BookWithDetails[]>;
  addBookmark(bookmark: InsertBookmark): Promise<Bookmark>;
  removeBookmark(bookId: number, userId: string): Promise<boolean>;
  isBookmarked(bookId: number, userId: string): Promise<boolean>;

  // Download tracking
  trackDownload(bookId: number, userId?: string, ipAddress?: string, userAgent?: string): Promise<void>;

  // Analytics
  getAdminStats(): Promise<{
    totalBooks: number;
    totalUsers: number;
    totalDownloads: number;
    totalReviews: number;
  }>;
  getRecentBooks(limit: number): Promise<Book[]>;
  getPopularBooks(limit: number): Promise<BookWithDetails[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(asc(categories.name));
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  // Book operations
  async getBooks(params: {
    page?: number;
    limit?: number;
    search?: string;
    categoryId?: number;
    sortBy?: "newest" | "rating" | "downloads" | "title";
    minRating?: number;
    language?: string;
    year?: number;
  }): Promise<{ books: BookWithDetails[]; total: number }> {
    const {
      page = 1,
      limit = 12,
      search,
      categoryId,
      sortBy = "newest",
      minRating,
      language,
      year
    } = params;
    const offset = (page - 1) * limit;

    let whereConditions = [];

    if (search) {
      whereConditions.push(
        or(
          ilike(books.title, `%${search}%`),
          ilike(books.author, `%${search}%`),
          ilike(books.description, `%${search}%`)
        )
      );
    }

    if (categoryId) {
      whereConditions.push(eq(books.categoryId, categoryId));
    }

    if (minRating) {
      whereConditions.push(sql`${books.averageRating} >= ${minRating}`);
    }

    if (language) {
      whereConditions.push(eq(books.language, language));
    }

    if (year) {
      whereConditions.push(eq(books.publicationYear, year));
    }

    const whereClause = whereConditions.length > 0 ? and(...whereConditions) : undefined;

    // Sorting
    let orderBy;
    switch (sortBy) {
      case "rating":
        orderBy = desc(books.averageRating);
        break;
      case "downloads":
        orderBy = desc(books.downloadCount);
        break;
      case "title":
        orderBy = asc(books.title);
        break;
      default:
        orderBy = desc(books.createdAt);
    }

    // Get total count
    const [totalResult] = await db
      .select({ count: count() })
      .from(books)
      .where(whereClause);

    // Get books with details
    const bookResults = await db
      .select({
        book: books,
        category: categories,
        uploadedBy: users,
      })
      .from(books)
      .leftJoin(categories, eq(books.categoryId, categories.id))
      .leftJoin(users, eq(books.uploadedById, users.id))
      .where(whereClause)
      .orderBy(orderBy)
      .limit(limit)
      .offset(offset);

    const booksWithDetails = await Promise.all(
      bookResults.map(async (result) => {
        const bookReviews = await this.getBookReviews(result.book.id);
        return {
          ...result.book,
          category: result.category,
          uploadedBy: result.uploadedBy,
          reviews: bookReviews,
        } as BookWithDetails;
      })
    );

    return {
      books: booksWithDetails,
      total: totalResult.count,
    };
  }

  async getBookById(id: number, userId?: string): Promise<BookWithDetails | undefined> {
    const [result] = await db
      .select({
        book: books,
        category: categories,
        uploadedBy: users,
      })
      .from(books)
      .leftJoin(categories, eq(books.categoryId, categories.id))
      .leftJoin(users, eq(books.uploadedById, users.id))
      .where(eq(books.id, id));

    if (!result) return undefined;

    const bookReviews = await this.getBookReviews(id);
    const isBookmarked = userId ? await this.isBookmarked(id, userId) : false;

    return {
      ...result.book,
      category: result.category,
      uploadedBy: result.uploadedBy,
      reviews: bookReviews,
      isBookmarked,
    };
  }

  async createBook(book: InsertBook): Promise<Book> {
    const [newBook] = await db.insert(books).values(book).returning();
    return newBook;
  }

  async updateBook(id: number, book: Partial<InsertBook>): Promise<Book | undefined> {
    const [updatedBook] = await db
      .update(books)
      .set({ ...book, updatedAt: new Date() })
      .where(eq(books.id, id))
      .returning();
    return updatedBook;
  }

  async deleteBook(id: number): Promise<boolean> {
    const result = await db.delete(books).where(eq(books.id, id));
    return result.rowCount > 0;
  }

  async incrementDownloadCount(bookId: number): Promise<void> {
    await db
      .update(books)
      .set({ downloadCount: sql`${books.downloadCount} + 1` })
      .where(eq(books.id, bookId));
  }

  // Review operations
  async getBookReviews(bookId: number): Promise<ReviewWithUser[]> {
    const reviewResults = await db
      .select({
        review: reviews,
        user: users,
      })
      .from(reviews)
      .leftJoin(users, eq(reviews.userId, users.id))
      .where(eq(reviews.bookId, bookId))
      .orderBy(desc(reviews.createdAt));

    return reviewResults.map((result) => ({
      ...result.review,
      user: result.user!,
    }));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    await this.updateBookRating(review.bookId);
    return newReview;
  }

  async updateBookRating(bookId: number): Promise<void> {
    const [ratingResult] = await db
      .select({
        avgRating: sql<number>`AVG(${reviews.rating}::float)`,
        totalRatings: count(),
      })
      .from(reviews)
      .where(eq(reviews.bookId, bookId));

    if (ratingResult) {
      await db
        .update(books)
        .set({
          averageRating: ratingResult.avgRating || 0,
          totalRatings: ratingResult.totalRatings,
        })
        .where(eq(books.id, bookId));
    }
  }

  // Bookmark operations
  async getBookmarks(userId: string): Promise<BookWithDetails[]> {
    const bookmarkResults = await db
      .select({
        book: books,
        category: categories,
        uploadedBy: users,
      })
      .from(bookmarks)
      .leftJoin(books, eq(bookmarks.bookId, books.id))
      .leftJoin(categories, eq(books.categoryId, categories.id))
      .leftJoin(users, eq(books.uploadedById, users.id))
      .where(eq(bookmarks.userId, userId))
      .orderBy(desc(bookmarks.createdAt));

    return await Promise.all(
      bookmarkResults.map(async (result) => {
        const bookReviews = await this.getBookReviews(result.book!.id);
        return {
          ...result.book!,
          category: result.category,
          uploadedBy: result.uploadedBy,
          reviews: bookReviews,
          isBookmarked: true,
        } as BookWithDetails;
      })
    );
  }

  async addBookmark(bookmark: InsertBookmark): Promise<Bookmark> {
    const [newBookmark] = await db.insert(bookmarks).values(bookmark).returning();
    return newBookmark;
  }

  async removeBookmark(bookId: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(bookmarks)
      .where(and(eq(bookmarks.bookId, bookId), eq(bookmarks.userId, userId)));
    return result.rowCount > 0;
  }

  async isBookmarked(bookId: number, userId: string): Promise<boolean> {
    const [result] = await db
      .select()
      .from(bookmarks)
      .where(and(eq(bookmarks.bookId, bookId), eq(bookmarks.userId, userId)));
    return !!result;
  }

  // Download tracking
  async trackDownload(
    bookId: number,
    userId?: string,
    ipAddress?: string,
    userAgent?: string
  ): Promise<void> {
    await db.insert(downloads).values({
      bookId,
      userId,
      ipAddress,
      userAgent,
    });
    await this.incrementDownloadCount(bookId);
  }

  // Analytics
  async getAdminStats(): Promise<{
    totalBooks: number;
    totalUsers: number;
    totalDownloads: number;
    totalReviews: number;
  }> {
    const [booksCount] = await db.select({ count: count() }).from(books);
    const [usersCount] = await db.select({ count: count() }).from(users);
    const [downloadsCount] = await db.select({ count: count() }).from(downloads);
    const [reviewsCount] = await db.select({ count: count() }).from(reviews);

    return {
      totalBooks: booksCount.count,
      totalUsers: usersCount.count,
      totalDownloads: downloadsCount.count,
      totalReviews: reviewsCount.count,
    };
  }

  async getRecentBooks(limit: number): Promise<Book[]> {
    return await db
      .select()
      .from(books)
      .orderBy(desc(books.createdAt))
      .limit(limit);
  }

  async getPopularBooks(limit: number): Promise<BookWithDetails[]> {
    const bookResults = await db
      .select({
        book: books,
        category: categories,
        uploadedBy: users,
      })
      .from(books)
      .leftJoin(categories, eq(books.categoryId, categories.id))
      .leftJoin(users, eq(books.uploadedById, users.id))
      .orderBy(desc(books.downloadCount))
      .limit(limit);

    return await Promise.all(
      bookResults.map(async (result) => {
        const bookReviews = await this.getBookReviews(result.book.id);
        return {
          ...result.book,
          category: result.category,
          uploadedBy: result.uploadedBy,
          reviews: bookReviews,
        } as BookWithDetails;
      })
    );
  }
}

export const storage = new DatabaseStorage();
