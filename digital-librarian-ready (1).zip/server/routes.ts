import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertBookSchema, insertReviewSchema, insertBookmarkSchema, insertCategorySchema } from "@shared/schema";
import { z } from "zod";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, `${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const upload = multer({
  storage: fileStorage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'));
    }
  },
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Categories routes
  app.get('/api/categories', async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post('/api/categories', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(categoryData);
      res.json(category);
    } catch (error) {
      console.error("Error creating category:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid category data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  // Books routes
  app.get('/api/books', async (req, res) => {
    try {
      const {
        page = 1,
        limit = 12,
        search,
        categoryId,
        sortBy = "newest",
        minRating,
        language,
        year
      } = req.query;

      const params = {
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        search: search as string,
        categoryId: categoryId ? parseInt(categoryId as string) : undefined,
        sortBy: sortBy as "newest" | "rating" | "downloads" | "title",
        minRating: minRating ? parseFloat(minRating as string) : undefined,
        language: language as string,
        year: year ? parseInt(year as string) : undefined,
      };

      const result = await storage.getBooks(params);
      res.json(result);
    } catch (error) {
      console.error("Error fetching books:", error);
      res.status(500).json({ message: "Failed to fetch books" });
    }
  });

  app.get('/api/books/:id', async (req: any, res) => {
    try {
      const bookId = parseInt(req.params.id);
      const userId = req.user?.claims?.sub;
      
      const book = await storage.getBookById(bookId, userId);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      res.json(book);
    } catch (error) {
      console.error("Error fetching book:", error);
      res.status(500).json({ message: "Failed to fetch book" });
    }
  });

  app.post('/api/books', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const file = req.file;
      
      if (!file) {
        return res.status(400).json({ message: "PDF file is required" });
      }

      const bookData = {
        ...req.body,
        categoryId: req.body.categoryId ? parseInt(req.body.categoryId) : null,
        publicationYear: req.body.publicationYear ? parseInt(req.body.publicationYear) : null,
        pageCount: req.body.pageCount ? parseInt(req.body.pageCount) : null,
        isFree: req.body.isFree === 'true',
        fileName: file.originalname,
        filePath: file.path,
        fileSize: file.size,
        uploadedById: userId,
      };

      const validatedData = insertBookSchema.parse(bookData);
      const book = await storage.createBook(validatedData);
      res.json(book);
    } catch (error) {
      console.error("Error creating book:", error);
      if (req.file) {
        // Clean up uploaded file on error
        fs.unlinkSync(req.file.path);
      }
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid book data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create book" });
    }
  });

  app.put('/api/books/:id', isAuthenticated, async (req: any, res) => {
    try {
      const bookId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const book = await storage.getBookById(bookId);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }

      // Only allow admin or book owner to update
      if (!user?.isAdmin && book.uploadedById !== userId) {
        return res.status(403).json({ message: "Permission denied" });
      }

      const updateData = {
        ...req.body,
        categoryId: req.body.categoryId ? parseInt(req.body.categoryId) : undefined,
        publicationYear: req.body.publicationYear ? parseInt(req.body.publicationYear) : undefined,
        pageCount: req.body.pageCount ? parseInt(req.body.pageCount) : undefined,
        isFree: req.body.isFree !== undefined ? req.body.isFree : undefined,
      };

      const updatedBook = await storage.updateBook(bookId, updateData);
      res.json(updatedBook);
    } catch (error) {
      console.error("Error updating book:", error);
      res.status(500).json({ message: "Failed to update book" });
    }
  });

  app.delete('/api/books/:id', isAuthenticated, async (req: any, res) => {
    try {
      const bookId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const book = await storage.getBookById(bookId);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }

      // Only allow admin or book owner to delete
      if (!user?.isAdmin && book.uploadedById !== userId) {
        return res.status(403).json({ message: "Permission denied" });
      }

      // Delete file if exists
      if (book.filePath && fs.existsSync(book.filePath)) {
        fs.unlinkSync(book.filePath);
      }

      const deleted = await storage.deleteBook(bookId);
      if (deleted) {
        res.json({ message: "Book deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete book" });
      }
    } catch (error) {
      console.error("Error deleting book:", error);
      res.status(500).json({ message: "Failed to delete book" });
    }
  });

  // Download route
  app.get('/api/books/:id/download', async (req: any, res) => {
    try {
      const bookId = parseInt(req.params.id);
      const userId = req.user?.claims?.sub;
      const ipAddress = req.ip;
      const userAgent = req.get('User-Agent');
      
      const book = await storage.getBookById(bookId);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }

      if (!book.filePath || !fs.existsSync(book.filePath)) {
        return res.status(404).json({ message: "File not found" });
      }

      // Track download
      await storage.trackDownload(bookId, userId, ipAddress, userAgent);

      res.download(book.filePath, book.fileName || `book-${bookId}.pdf`);
    } catch (error) {
      console.error("Error downloading book:", error);
      res.status(500).json({ message: "Failed to download book" });
    }
  });

  // Reviews routes
  app.get('/api/books/:id/reviews', async (req, res) => {
    try {
      const bookId = parseInt(req.params.id);
      const reviews = await storage.getBookReviews(bookId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.post('/api/books/:id/reviews', isAuthenticated, async (req: any, res) => {
    try {
      const bookId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const reviewData = {
        ...req.body,
        bookId,
        userId,
        rating: parseInt(req.body.rating),
      };

      const validatedData = insertReviewSchema.parse(reviewData);
      const review = await storage.createReview(validatedData);
      res.json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  // Bookmarks routes
  app.get('/api/bookmarks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookmarks = await storage.getBookmarks(userId);
      res.json(bookmarks);
    } catch (error) {
      console.error("Error fetching bookmarks:", error);
      res.status(500).json({ message: "Failed to fetch bookmarks" });
    }
  });

  app.post('/api/books/:id/bookmark', isAuthenticated, async (req: any, res) => {
    try {
      const bookId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const isAlreadyBookmarked = await storage.isBookmarked(bookId, userId);
      if (isAlreadyBookmarked) {
        return res.status(400).json({ message: "Book already bookmarked" });
      }

      const bookmarkData = { bookId, userId };
      const validatedData = insertBookmarkSchema.parse(bookmarkData);
      const bookmark = await storage.addBookmark(validatedData);
      res.json(bookmark);
    } catch (error) {
      console.error("Error adding bookmark:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid bookmark data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add bookmark" });
    }
  });

  app.delete('/api/books/:id/bookmark', isAuthenticated, async (req: any, res) => {
    try {
      const bookId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const removed = await storage.removeBookmark(bookId, userId);
      if (removed) {
        res.json({ message: "Bookmark removed successfully" });
      } else {
        res.status(404).json({ message: "Bookmark not found" });
      }
    } catch (error) {
      console.error("Error removing bookmark:", error);
      res.status(500).json({ message: "Failed to remove bookmark" });
    }
  });

  // Admin routes
  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  app.get('/api/admin/recent-books', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const limit = parseInt(req.query.limit as string) || 5;
      const books = await storage.getRecentBooks(limit);
      res.json(books);
    } catch (error) {
      console.error("Error fetching recent books:", error);
      res.status(500).json({ message: "Failed to fetch recent books" });
    }
  });

  // Popular books route
  app.get('/api/books/popular', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const books = await storage.getPopularBooks(limit);
      res.json(books);
    } catch (error) {
      console.error("Error fetching popular books:", error);
      res.status(500).json({ message: "Failed to fetch popular books" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
